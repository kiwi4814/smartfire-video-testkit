# SmartFire Video Provider Contract

The published contract is the versioned archive under `releases/1.0.0-draft.1/`.
SmartFire, TestKit, WVP Provider, and SIPGO consumers must pin both:

- Contract version: `1.0.0-draft.1`
- Archive SHA-256: the value in the adjacent `.tar.gz.sha256` file

Consumers acquire the same archive from the SmartFire source release, verify its
SHA-256 before extraction, and generate or validate models from `openapi.yaml` and
`schemas/provider.schema.json`. Consumers must not copy, hand-write, or extend
Provider contract schemas independently.

The archive is self-contained contract data and can be transferred to an offline
environment. Its `bundle-manifest.json` records every payload checksum and the
published structural and semantic authorities.

From the SmartFire repository, the single release gate is:

```text
just video-contract-check
```
