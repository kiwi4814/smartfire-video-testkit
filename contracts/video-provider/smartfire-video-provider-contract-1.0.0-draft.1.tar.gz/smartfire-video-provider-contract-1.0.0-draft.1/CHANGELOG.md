# Video Provider Contract Changelog

## [1.0.0-draft.1] - 2026-08-10

### Added

- Published the OpenAPI 3.1 contract entry point for liveness, readiness, provider information, and capabilities.
- Added the generated JSON Schema 2020-12 handshake bundle and versioned success/error examples.
- Added deterministic lint, schema synchronization, example validation, and breaking-change fixture checks.
- Added pinned Java server/client and Go server generation/compilation smoke checks.
- Bound every example to an operation and schema, including stable error code and retryability semantics.
- Added Provider device, channel, status, and asynchronous Catalog synchronization operations.
- Added normal, empty, multi-channel NVR, partial, timeout, not-found, and idempotency-conflict examples.
- Prohibited Provider database identifiers, credentials, and SIP runtime fields from shared inventory projections.
- Added the live stream lifecycle operations with stable `startLiveStream`, `getLiveStream`, and `stopLiveStream` operationIds.
- Added `201` creation, `200` reuse, concurrent/same-key retry, and idempotent `204` stop examples with the complete observable stream lifecycle.
- Added live-stream error examples for offline devices, missing channels, unavailable media, INVITE timeout, start/stop failures, and missing stream keys.
- Restricted Media Stream Reference to `mediaServerId`, `vhost`, `app`, and `streamId`; added negative validation for leaked media implementation fields in error details.
- Added asynchronous Device Record Query and Playback Stream operations, including partial results, opaque record keys, idempotent playback stop, and stable record/playback errors.
- Prohibited SmartFire platform recording, download, path, business-name, and storage-lifecycle fields from Provider device-record models.
- Added the dedicated Provider Event webhook, epoch-aware revision and snapshot reconciliation semantics, callback Bearer authentication, and event delivery vectors.
- Added the deterministic offline release archive, payload manifest, SHA-256 sidecar, and machine-readable release report.
- Standardized all four consumers on the same versioned archive and checksum pinning workflow.
- Added explicit comparison against the latest published OpenAPI baseline and unpacked Python, Java, and Go consumer verification.

### Compatibility

Initial draft baseline remains the version origin. This release was compared explicitly with the Contract 05 published OpenAPI baseline at commit `2604d85f74cc83602a8b867fe89209be44e2d930`; no breaking change detected.
