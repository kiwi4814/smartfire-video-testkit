# SmartFire 视频 Provider 共同契约基线

> 状态：Baseline
>
> 文档版本：`1.0.0-draft.1`
>
> 适用实现：`smartfire-wvp-provider`、`smartfire-sipgo`
>
> 决策依据：[`ADR-0007`](../adr/0007-standardize-video-provider-contract.md)

## 1. 目的

本契约定义 SmartFire 与视频信令 Provider 之间唯一稳定的内部接口。它屏蔽 WVP、sipgo、JAIN-SIP、Provider 数据库和 ZLMediaKit 编排差异，使一期和二期能够使用同一业务兼容层、同一模拟器和同一套契约测试。

本文使用以下规范词：

- **必须（MUST）**：不满足即不符合契约；
- **应该（SHOULD）**：除非有明确且记录在案的理由，否则必须满足；
- **可以（MAY）**：可选能力，必须通过 Capabilities 声明。

## 2. 范围

### 2.1 必选能力

- 存活、就绪、版本与能力查询；
- Provider 设备和通道发现；
- Catalog 同步及结果查询；
- 设备、通道在线状态；
- 实时流启动、查询和停止；
- 设备录像目录查询；
- 设备录像回放启动和停止；
- Provider 事件投递；
- 全量目录对账所需的分页查询；
- 稳定错误、幂等和超时语义。

### 2.2 不属于本契约

- SmartFire 面向浏览器的 `/integration/video/**` 业务接口；
- 用户、角色、菜单和数据权限；
- 建筑、楼层、安装位置和业务设备名称；
- 平台 MP4 录像管理、文件下载和抓图业务元数据；
- ZLMediaKit 原始 REST API 和 WebHook；
- PTZ、语音对讲、广播、国标级联、JT1078、AI 分析；
- Provider 数据库迁移和表结构；
- 部署端口、证书和密钥分发。

平台录像和服务端抓图由 SmartFire 的 `VideoMediaPort`/ZLMediaKit Adapter 完成。SmartFire 可以先建立或复用实时流，再执行 ZLM 录像或抓图，不要求信令 Provider 暴露平台录像接口。

## 3. 角色与数据所有权

| 对象 | Owner | 说明 |
|---|---|---|
| `iot.device` 视频资产 | SmartFire | 业务名称、企业、建筑、楼层、位置和生命周期 |
| Provider Binding | SmartFire | SmartFire 设备与 GB Device/Channel 的稳定映射 |
| Provider Device/Channel | Provider | 协议发现结果和技术投影 |
| 在线状态业务投影 | SmartFire | Provider 观察值经幂等同步后的最近状态 |
| SIP Dialog、Call-ID、SSRC、RTP 端口 | Provider/Redis/内存 | 可过期、可重建，不进入业务库 |
| 平台录像和抓图元数据 | SmartFire | 跨 Provider 保留 |
| 媒体流与文件 | ZLMediaKit/受控文件存储 | Provider 只返回媒体引用 |

SmartFire 与 Provider **禁止**互相直连对方数据库，禁止跨库事务和跨库外键。同步采用事件加定期 reconciliation 的最终一致模型。

## 4. 共同术语

**Provider Instance**：一个可独立寻址、具备唯一 `providerInstanceCode` 的 Provider 运行实例。

**Provider Epoch**：Provider 每次进程启动生成的 UUID，通过 `/info` 和事件暴露；revision 只能在同一 Epoch 内比较，Epoch 改变必须触发 full reconciliation。

**External Device ID**：GB28181 注册设备身份，通常是 GB Device ID。

**External Channel ID**：Catalog 中的可播放通道身份。

**Protocol Source Identity**：`externalDeviceId + externalChannelId`；在同一 SIP 域内跨 WVP/Gateway 切换时保持稳定。

**Provider Resource Identity**：`providerInstanceCode + externalDeviceId + externalChannelId`；用于两个 Provider 并行运行时区分各自观察值。

**Provider Stream Key**：Provider 为一次源流分配的短期运行态标识。

**Media Stream Reference**：`mediaServerId + vhost + app + streamId`，用于 SmartFire 调用 ZLM。

**Logical Live Session**：SmartFire 为用户/窗口维护的会话，不属于 Provider 契约。多个 Logical Live Session 可以复用一个 Provider Stream。

**Catalog Sync**：触发 Provider 向一个设备重新查询目录的异步操作。

**Reconciliation**：SmartFire 分页读取 Provider 当前目录并修复漏事件、缺失标记和状态漂移；不是“先删后插”。

## 5. 协议通则

### 5.1 HTTP 与路径

- Base Path：`/provider/v1`；
- 使用 HTTPS 或受控一体机内部网络中的 HTTP；
- JSON 字段采用 `camelCase`；
- 请求和响应使用 `Content-Type: application/json`，二进制流不在本契约中传输；
- Provider 必须正确使用 HTTP 状态码，不能始终返回 `200` 再依赖业务字段判断失败。

### 5.2 通用请求头

| Header | 要求 | 说明 |
|---|---|---|
| `X-Request-Id` | SHOULD | 调用方生成；缺失时 Provider 生成并回传 |
| `Idempotency-Key` | 写操作 MUST | 同一操作和同一资源范围内唯一，建议 UUID |
| `Authorization: Bearer <token>` | 生产 MUST | 开发环境可显式关闭；不得在日志输出 token |
| `Accept` | SHOULD | `application/json` |

部署阶段可以决定 token 的生成和轮换方式，但实现必须保留认证能力。未启用认证的实例只能绑定环回地址或受控内部网络。

### 5.3 时间、ID 与枚举

- 所有 ID 在 JSON 中均为字符串；
- 时间使用 RFC 3339、带时区，Provider 输出应统一为 UTC `Z`，精度到毫秒；
- 时间区间采用左闭右开 `[startTime, endTime)`；
- `revision` 使用无前导零的 uint64 十进制字符串，仅在同一 `providerInstanceCode + providerEpoch + resource identity` 内单调可比；
- 不透明 `snapshotToken` 只用于一次 inventory 稳定分页，不得包含数据库 ID、凭据或可推断内部结构；
- 未知字段必须忽略，以支持向后兼容；
- 未知枚举不得静默映射成已有含义，应保留原值或返回受控兼容错误；
- `null` 表示“已知为空”，字段缺失表示“本版本未提供/不适用”。

### 5.4 成功响应

```json
{
  "requestId": "9fe3bfc2-8db7-4fb2-a64f-bf2183582163",
  "data": {}
}
```

分页响应的 `data`：

```json
{
  "items": [],
  "page": 1,
  "pageSize": 100,
  "total": 0
}
```

- `page` 从 1 开始；
- 默认 `pageSize=100`，最大 `500`；
- 相同查询在数据未变化时必须按稳定身份排序；
- Provider 不得通过返回超大无分页数组规避分页契约。

### 5.5 错误响应

```json
{
  "requestId": "9fe3bfc2-8db7-4fb2-a64f-bf2183582163",
  "error": {
    "code": "VIDEO_DEVICE_OFFLINE",
    "message": "Device is offline",
    "retryable": false,
    "details": {
      "externalDeviceId": "34020000001320000001"
    }
  }
}
```

- `message` 用于诊断，不得被调用方解析；
- `details` 只能包含脱敏、结构化信息；
- 不得返回堆栈、SQL、密码、token、ZLM secret、内部绝对路径；
- 调用方只依赖 `code`、HTTP 状态和 `retryable`。

## 6. 版本与兼容策略

- URL 主版本固定为 `/provider/v1`；
- 同一主版本内只允许增加可选字段、可选能力和新错误码；
- 删除字段、改变字段含义、收紧有效值或改变幂等语义必须升级主版本；
- Provider 的 `/info` 必须返回 `contractVersion`；
- Provider 可以比 SmartFire 支持更多字段，但必须通过 Capabilities 声明行为能力；
- 共同 OpenAPI 发布后，OpenAPI 和 JSON Schema 是结构事实源，本文是语义事实源；二者冲突必须阻断发布并修复。

## 7. 端点总览

| 方法 | 路径 | 说明 |
|---|---|---|
| GET | `/health/live` | 进程存活 |
| GET | `/health/ready` | 核心依赖和监听就绪 |
| GET | `/info` | 实现与构建信息 |
| GET | `/capabilities` | 能力声明 |
| GET | `/devices` | 分页设备目录 |
| GET | `/devices/{externalDeviceId}` | 单设备 |
| GET | `/devices/{externalDeviceId}/channels` | 分页通道目录 |
| GET | `/devices/{externalDeviceId}/status` | 设备当前状态 |
| POST | `/devices/{externalDeviceId}/catalog-syncs` | 发起 Catalog 同步 |
| GET | `/catalog-syncs/{operationId}` | 查询同步结果 |
| POST | `/live-streams` | 启动/复用实时源流 |
| GET | `/live-streams/{providerStreamKey}` | 查询源流 |
| DELETE | `/live-streams/{providerStreamKey}` | 幂等停止源流 |
| POST | `/device-record-queries` | 发起设备录像查询 |
| GET | `/device-record-queries/{queryId}` | 查询录像目录结果 |
| POST | `/playback-streams` | 启动设备录像回放流 |
| GET | `/playback-streams/{providerStreamKey}` | 查询回放流 |
| DELETE | `/playback-streams/{providerStreamKey}` | 幂等停止回放流 |

## 8. 健康、信息与能力

### 8.1 `GET /health/live`

只表示进程可以处理 HTTP，不检查所有远端依赖。成功返回 `200`：

```json
{
  "requestId": "...",
  "data": {"status": "UP"}
}
```

### 8.2 `GET /health/ready`

就绪条件至少包括：

- SIP TCP/UDP 监听已建立；
- Provider 必需的 PostgreSQL/Redis 可用（若该实现需要）；
- ZLM 可达，或实现明确支持“ZLM 暂不可用但只读目录可用”的降级状态；
- 启动恢复和必要初始化已经结束。

响应可以是 `READY`、`DEGRADED`、`NOT_READY`。`NOT_READY` 使用 `503`。

### 8.3 `GET /info`

```json
{
  "requestId": "...",
  "data": {
    "providerType": "WVP",
    "providerInstanceCode": "video-main",
    "contractVersion": "1.0.0-draft.1",
    "implementationVersion": "0.1.0",
    "providerEpoch": "3f3c8f78-08a7-4b6a-a4f7-b0d73fca24fb",
    "buildCommit": "abc1234",
    "buildTime": "2026-08-10T01:00:00.000Z",
    "protocolStack": "WVP"
  }
}
```

`providerType` 基线值：`WVP`、`SIPGO_GATEWAY`、`MOCK`。`providerEpoch` 每次进程启动必须变化；Consumer 观察到变化后不得跨 Epoch 比较 revision，并必须触发 full reconciliation。

### 8.4 `GET /capabilities`

响应结构：

```json
{
  "requestId": "...",
  "data": {
    "capabilities": [
      {"code": "DEVICE_DISCOVERY", "supported": true, "constraints": {}},
      {"code": "PLAYBACK_SPEED", "supported": false, "constraints": {}}
    ]
  }
}
```

必选能力：

```text
DEVICE_DISCOVERY
CATALOG_SYNC
LIVE_STREAM
DEVICE_RECORD_QUERY
DEVICE_RECORD_PLAYBACK
PROVIDER_EVENTS
```

可选能力预留：

```text
SNAPSHOT
PTZ
PLAYBACK_SEEK
PLAYBACK_SPEED
DEVICE_RECORD_DOWNLOAD
TALK
BROADCAST
PLATFORM_CASCADE
```
上述代码仅预留未来契约扩展的稳定名称；v1 尚未定义对应端点和 Schema，Provider 必须声明 `supported=false`。其中 `SNAPSHOT` 仅表示未来可能增加的设备侧抓图，平台和服务端抓图仍由 SmartFire 的 ZLMediaKit Adapter 负责。

Provider 不能通过接口存在推断能力；行为必须以 Capabilities 为准。调用未声明能力返回 `VIDEO_CAPABILITY_NOT_SUPPORTED`。

## 9. 设备与通道

分页查询参数：

```text
GET /devices?page=1&pageSize=100&query=&onlineStatus=&updatedAfter=
GET /devices?page=2&pageSize=100&query=&onlineStatus=&snapshotToken=<opaque>
GET /devices/{externalDeviceId}/channels?page=1&pageSize=100&query=&onlineStatus=
GET /devices/{externalDeviceId}/channels?page=2&pageSize=100&query=&onlineStatus=&snapshotToken=<opaque>
```

分页响应的 `data` 除 `items/page/pageSize/total` 外必须返回 `snapshotToken`。首个全量页创建 token；使用 token 的后续页回传同一值。

- `query` 只能匹配来源名称和协议身份，不承担 SmartFire 业务名称搜索；
- `onlineStatus` 使用共同状态枚举；
- `updatedAfter` 使用 RFC 3339，用于增量诊断，不能替代定期全量 reconciliation；
- 路径 ID 必须按 URL path segment 编码；
- 首个全量页返回不透明 `snapshotToken`，后续页必须回传同一 token；Provider 必须在有界 TTL/容量内保持该快照稳定；
- token 过期、不匹配或快照不可继续时返回 `409 VIDEO_CATALOG_SNAPSHOT_EXPIRED` 且 `retryable=true`，调用方必须放弃整轮；只有完整稳定快照可用于标记 MISSING。

### 9.1 ProviderDevice

```json
{
  "providerInstanceCode": "video-main",
  "externalDeviceId": "34020000001320000001",
  "sourceName": "NVR-01",
  "manufacturer": "HIKVISION",
  "model": "...",
  "firmwareVersion": "...",
  "transport": "UDP",
  "streamMode": "UDP",
  "charset": "GB2312",
  "onlineStatus": "ONLINE",
  "channelCount": 16,
  "lastSeenAt": "2026-08-10T01:00:00.000Z",
  "revision": "42"
}
```

规则：

- `externalDeviceId` 必须是 Provider 协议身份，不是数据库主键；
- 不返回密码、API Key、当前 SIP Contact、Call-ID、SSRC 或 RTP 端口；
- `sourceName` 是 Provider 来源名称，不具有覆盖 SmartFire 业务名称的权力；
- `onlineStatus`：`ONLINE`、`OFFLINE`、`UNKNOWN`；
- `revision` 遵守 5.3 的 Epoch/资源作用域，只能用于同一作用域内诊断和去除旧事件。

### 9.2 ProviderChannel

```json
{
  "providerInstanceCode": "video-main",
  "externalDeviceId": "34020000001320000001",
  "externalChannelId": "34020000001310000001",
  "parentExternalChannelId": null,
  "sourceName": "一楼东门",
  "manufacturer": "HIKVISION",
  "model": "...",
  "onlineStatus": "ONLINE",
  "resolution": "1920x1080",
  "codec": "H264",
  "hasAudio": true,
  "supportsPtz": false,
  "supportsDeviceRecord": true,
  "streamIdentification": null,
  "revision": "18"
}
```

SmartFire 以 Provider Resource Identity 幂等 Upsert Provider 投影，以 Protocol Source Identity 保持跨 Provider 的业务绑定。Catalog 缺失的已绑定通道只能标记 `MISSING/OFFLINE/UNKNOWN`，不得自动删除业务设备、录像或抓图。

### 9.3 设备状态

`GET /devices/{externalDeviceId}/status`：

```json
{
  "requestId": "...",
  "data": {
    "externalDeviceId": "34020000001320000001",
    "onlineStatus": "ONLINE",
    "lastSeenAt": "2026-08-10T01:00:00.000Z",
    "observedAt": "2026-08-10T01:00:01.000Z",
    "revision": "42"
  }
}
```

`observedAt` 表示 Provider 生成当前响应的时间，`lastSeenAt` 表示最近观察到有效设备消息的时间。SmartFire 必须把两者分开，不能把查询时间伪装成设备最后在线时间。

## 10. Catalog 同步

`POST /devices/{externalDeviceId}/catalog-syncs` 必须接收 `Idempotency-Key`，成功受理返回 `202`：

```json
{
  "requestId": "...",
  "data": {
    "operationId": "catalog-01J5...",
    "status": "ACCEPTED",
    "submittedAt": "2026-08-10T01:00:00.000Z"
  }
}
```

`GET /catalog-syncs/{operationId}`：

```json
{
  "requestId": "...",
  "data": {
    "operationId": "catalog-01J5...",
    "externalDeviceId": "34020000001320000001",
    "status": "SUCCEEDED",
    "discoveredCount": 16,
    "completedAt": "2026-08-10T01:00:03.000Z",
    "error": null
  }
}
```

状态：`ACCEPTED`、`RUNNING`、`SUCCEEDED`、`PARTIAL`、`FAILED`、`EXPIRED`。

- 相同 Idempotency Key 和相同请求必须返回同一操作；
- 相同 Key 但语义不同返回 `409 VIDEO_IDEMPOTENCY_CONFLICT`；
- `PARTIAL` 必须保留已经发现的有效通道，并返回结构化原因；
- 操作结果至少保留 15 分钟，具体上限由实现配置；
- Catalog 同步不得实现为 SmartFire 侧“删除全部再插入”。

## 11. 实时流

### 11.1 启动

`POST /live-streams`：

```json
{
  "externalDeviceId": "34020000001320000001",
  "externalChannelId": "34020000001310000001",
  "streamProfile": "AUTO"
}
```

`streamProfile`：`AUTO`、`MAIN`、`SUB`。Provider 无法区分时可以把 `AUTO` 映射到默认码流，但不得伪造已选择主/子码流。

成功返回 `200`（复用）或 `201`（新建）：

```json
{
  "requestId": "...",
  "data": {
    "providerStreamKey": "live-01J5...",
    "externalDeviceId": "34020000001320000001",
    "externalChannelId": "34020000001310000001",
    "state": "STREAMING",
    "media": {
      "mediaServerId": "zlm-01",
      "vhost": "__defaultVhost__",
      "app": "rtp",
      "streamId": "34020000001310000001_01",
      "codec": "H264",
      "hasAudio": true
    },
    "sources": [
      {"protocol": "WEBRTC", "url": "...", "priority": 10},
      {"protocol": "WS_FLV", "url": "...", "priority": 20}
    ],
    "startedAt": "2026-08-10T01:00:00.000Z"
  }
}
```

规则：

- `Idempotency-Key` 必须支持网络超时后的安全重试；
- Provider 必须在确认 ZLM 已出现目标流后返回 `STREAMING`；
- `sources` 可以为空，SmartFire 可根据 Media Stream Reference 生成部署可访问地址；
- URL 中不得携带 Provider token、ZLM secret 或本地文件路径；
- SmartFire 负责用户级 refCount，Provider 不得要求传入用户 ID、窗口 ID 或权限信息。

### 11.2 状态

状态：`STARTING`、`STREAMING`、`STOPPING`、`STOPPED`、`FAILED`。

`GET /live-streams/{providerStreamKey}` 返回当前状态。未知或已过保留期的 Key 返回 `404 VIDEO_STREAM_NOT_FOUND`。

### 11.3 停止

`DELETE /live-streams/{providerStreamKey}` 必须幂等：

- 已停止或不存在的 Key 均返回 `204`，调用方不需要判断第一次 Stop 是否已经到达；
- `GET` 查询不存在的 Key 仍返回 `404 VIDEO_STREAM_NOT_FOUND`；
- 停止超时返回可重试错误，Provider 后台仍应执行孤儿流清理；
- Stop 成功后最终释放 SIP Dialog、SSRC 和 RTP 端口。

## 12. 设备录像查询

`POST /device-record-queries`：

```json
{
  "externalDeviceId": "34020000001320000001",
  "externalChannelId": "34020000001310000001",
  "startTime": "2026-08-10T00:00:00.000Z",
  "endTime": "2026-08-10T01:00:00.000Z",
  "recordType": "ALL"
}
```

请求必须携带 `Idempotency-Key`，返回 `202` 和 `queryId`。`recordType`：`ALL`、`TIME`、`ALARM`、`MANUAL`，不支持的精细类型可以仅支持 `ALL` 并在 Capabilities/Info 中说明。

`GET /device-record-queries/{queryId}` 返回：

```json
{
  "requestId": "...",
  "data": {
    "queryId": "record-query-01J5...",
    "status": "SUCCEEDED",
    "items": [
      {
        "recordKey": "opaque-provider-key",
        "externalDeviceId": "34020000001320000001",
        "externalChannelId": "34020000001310000001",
        "startTime": "2026-08-10T00:10:00.000Z",
        "endTime": "2026-08-10T00:20:00.000Z",
        "recordType": "TIME",
        "sizeBytes": null,
        "sourceAddress": null
      }
    ],
    "completedAt": "2026-08-10T01:00:05.000Z"
  }
}
```

- Provider 必须聚合设备多条 MESSAGE/分页响应；
- 查询超时可以返回 `PARTIAL` 和已收集 items；
- `recordKey` 是不透明 Provider Key，不得被 SmartFire 当业务主键；
- 设备录像目录是设备侧实时查询结果，不等同于 SmartFire 平台录像记录。

## 13. 设备录像回放

`POST /playback-streams`：

```json
{
  "externalDeviceId": "34020000001320000001",
  "externalChannelId": "34020000001310000001",
  "recordKey": "opaque-provider-key",
  "startTime": "2026-08-10T00:10:00.000Z",
  "endTime": "2026-08-10T00:20:00.000Z"
}
```

`recordKey` 优先；Provider 无法只凭 recordKey 回放时，使用同一条查询结果的时间范围。返回结构与实时流一致，但流类型为 `PLAYBACK`。

- 必须支持 `Idempotency-Key`；
- 查询、回放的 Device/Channel/时间必须一致，否则返回 `VIDEO_RECORD_MISMATCH`；
- `DELETE /playback-streams/{providerStreamKey}` 幂等；
- seek、speed、pause/resume 不属于 v1 必选能力。

## 14. Provider 事件

Provider 向 SmartFire 配置的回调地址投递：

```text
POST /internal/integration/video/provider-events
```

Envelope：

```json
{
  "eventId": "88fc89f2-8ad7-4d99-a04a-cdb05206b32a",
  "eventType": "CHANNEL_ONLINE",
  "providerType": "WVP",
  "providerInstanceCode": "video-main",
  "occurredAt": "2026-08-10T01:00:00.000Z",
  "providerEpoch": "3f3c8f78-08a7-4b6a-a4f7-b0d73fca24fb",
  "revision": "43",
  "resource": {
    "externalDeviceId": "34020000001320000001",
    "externalChannelId": "34020000001310000001"
  },
  "data": {}
}
```

基线事件：

```text
DEVICE_ONLINE
DEVICE_OFFLINE
CATALOG_CHANGED
CHANNEL_ONLINE
CHANNEL_OFFLINE
```

投递语义：

- 至少一次；
- v1 回调固定使用独立 `Authorization: Bearer <token>`，生产环境不得匿名接收；token 只来自 Secret/config，不进入 payload、日志或业务表；
- SmartFire 对 `providerInstanceCode + eventId` 幂等；
- SmartFire 仅在持久化接收结果后返回 `2xx`；
- `401/403` 不盲目重试并产生配置告警，`5xx` 按有界指数退避重试；
- 事件允许乱序；SmartFire 只在同一 `providerInstanceCode + providerEpoch + resource identity` 内比较 revision，Epoch 改变时将运行态置 UNKNOWN 并触发 full reconciliation；
- 达到重试上限后记录可观测失败，最终由 reconciliation 修复；
- 事件中不得包含密码、token、完整 SIP 报文或 ZLM secret。

## 15. 幂等与并发

- 所有 POST 控制操作必须接收 `Idempotency-Key`；
- 幂等记录至少覆盖“最大下游超时 + 调用方重试窗口”，基线建议 24 小时；
- 相同 Key、相同资源和相同规范化请求返回同一结果；
- 相同 Key 对应不同请求返回 `409 VIDEO_IDEMPOTENCY_CONFLICT`；
- 对同一 Channel 并发 start，Provider 必须只建立一个等价源流或返回同一 Stream；
- SmartFire 不得在超时后无 Key 重试 start；
- Stop 和事件接收必须天然幂等。

## 16. 超时和重试

调用方默认上限建议，最终值由实测配置：

| 操作 | HTTP 等待 | 说明 |
|---|---:|---|
| health/info/capabilities | 2 秒 | 不重试写操作 |
| 设备/通道分页查询 | 5 秒 | 只读可有限重试 |
| Catalog 提交 | 3 秒 | 异步查询结果 |
| Live/Playback start | 20 秒 | 必须携带幂等 Key |
| Stop | 10 秒 | 幂等，可查询状态补偿 |
| Device Record Query 提交 | 3 秒 | 异步查询结果 |

Provider 内部超时必须小于调用方总超时，并为响应映射和网络留出余量。只有标记为 `retryable=true` 且调用具备幂等保护时才允许自动重试。

## 17. 稳定错误

| Code | HTTP | Retryable | 含义 |
|---|---:|---:|---|
| `VIDEO_INVALID_ARGUMENT` | 400 | 否 | 参数或时间范围非法 |
| `VIDEO_PROVIDER_AUTH_FAILED` | 401/403 | 否 | 服务认证失败 |
| `VIDEO_IDEMPOTENCY_CONFLICT` | 409 | 否 | 幂等 Key 被不同请求复用 |
| `VIDEO_PROVIDER_UNAVAILABLE` | 503 | 是 | Provider 核心依赖不可用 |
| `VIDEO_PROVIDER_TIMEOUT` | 504 | 是 | Provider 内部操作超时 |
| `VIDEO_DEVICE_NOT_FOUND` | 404 | 否 | 设备不存在 |
| `VIDEO_DEVICE_OFFLINE` | 422 | 否 | 设备离线 |
| `VIDEO_CHANNEL_NOT_FOUND` | 404 | 否 | 通道不存在 |
| `VIDEO_CATALOG_TIMEOUT` | 504 | 是 | Catalog 超时 |
| `VIDEO_CATALOG_SNAPSHOT_EXPIRED` | 409 | 是 | inventory snapshotToken 过期、不匹配或无法继续 |
| `VIDEO_CATALOG_PARTIAL` | 200/状态 | 视场景 | Catalog 部分完成，通常体现在操作状态 |
| `VIDEO_STREAM_START_FAILED` | 502 | 视场景 | 实时流启动失败 |
| `VIDEO_STREAM_STOP_FAILED` | 502 | 是 | 实时流停止失败 |
| `VIDEO_STREAM_NOT_FOUND` | 404 | 否 | Stream Key 不存在 |
| `VIDEO_MEDIA_UNAVAILABLE` | 503 | 是 | ZLM 不可用 |
| `VIDEO_RTP_ALLOCATE_FAILED` | 503 | 是 | RTP/SSRC 资源分配失败 |
| `VIDEO_UNSUPPORTED_CODEC` | 422 | 否 | 编码不支持 |
| `VIDEO_RECORD_QUERY_TIMEOUT` | 504 | 是 | 设备录像查询超时 |
| `VIDEO_RECORD_NOT_FOUND` | 404 | 否 | 录像项不存在 |
| `VIDEO_RECORD_MISMATCH` | 409 | 否 | 录像 Key 与设备/时间不一致 |
| `VIDEO_PLAYBACK_START_FAILED` | 502 | 视场景 | 回放启动失败 |
| `VIDEO_CAPABILITY_NOT_SUPPORTED` | 422 | 否 | 能力未声明或不支持 |

Provider 可以增加诊断子码，但 SmartFire 业务判断只能依赖上述稳定码。

## 18. 安全与日志

- Provider 控制接口不得直接暴露到用户网络；
- 生产必须启用服务认证，开发关闭必须是显式 Profile；
- 日志必须携带 `requestId`、Provider Instance 和脱敏资源身份；
- 不记录 Authorization、设备密码、ZLM secret、完整 SDP 中的敏感参数；
- 不允许前端提交本地路径、ZLM app/stream 或 Provider Stream Key 来绕过 SmartFire 资源授权；
- SmartFire 必须先完成用户权限和数据范围校验，才能调用 Provider；Provider 不承担最终用户权限模型。

## 19. 一致性与切换约束

- Provider 事件是加速同步，不是唯一事实传输通道；
- SmartFire 必须定期分页读取设备和通道做 reconciliation；
- Provider 缺失的已绑定资源标记 `MISSING`，不得自动删除；
- Provider 来源名称变化不得覆盖用户维护的业务名称和空间位置；
- 一期 WVP 和二期 Gateway 必须保持相同 External Device/Channel ID；
- 切换 Provider 前必须完成目录对账、停止或排空活动流，并保留 WVP 数据库作为回滚快照；
- Gateway 不需要读取或迁移 WVP 数据库即可重建 SIP/Catalog 运行状态。

## 20. 契约治理

变更流程：

1. 提交语义变更说明和兼容性判断；
2. 更新本文；
3. 更新 OpenAPI/JSON Schema 和示例；
4. 先增加或修改失败的契约测试；
5. 更新 Mock Provider；
6. 更新 WVP Provider 和 sipgo Gateway；
7. 更新 SmartFire Consumer 测试；
8. 两个已交付 Provider 均通过后才能提升基线版本。

禁止行为：

- 只在某个实现中新增“临时字段”供 SmartFire 依赖；
- 通过 Provider 类型分支绕过共同契约；
- 修改已发布版本语义但不升级版本；
- 以 WVP 页面或单个 curl 成功代替契约验收。

## 21. v1 完成定义

契约从 Draft 提升为 `1.0.0` 前必须具备：

- OpenAPI 3.1 文件及 JSON Schema；
- 成功、失败和边缘场景示例；
- 黑盒共同契约测试；
- Fake Provider；
- GB28181 Device Simulator 的核心流程；
- `smartfire-wvp-provider` 全部必选测试通过；
- SmartFire Consumer 映射、字段所有权和幂等测试通过；
- 错误、超时、日志脱敏和重启恢复测试通过；
- 未实现的可选能力准确声明为 false。
