# SmartFire 视频 Provider 共同契约测试基线与实施计划

> 对应契约：[`SMARTFIRE-VIDEO-PROVIDER-CONTRACT-BASELINE.md`](SMARTFIRE-VIDEO-PROVIDER-CONTRACT-BASELINE.md)
>
> 状态：Planned Baseline
>
> 目标：用同一套黑盒测试验收 WVP Provider、sipgo Gateway 和 Mock Provider

## 1. 测试目标

共同契约测试证明的是：

1. Provider 的 HTTP 结构符合共同契约；
2. 不同实现对同一场景具有相同可观察语义；
3. SmartFire 可以在不增加 Provider 类型分支的情况下切换实现；
4. 幂等、错误、异步状态和事件语义在异常条件下仍成立；
5. Provider 内部实现和数据库差异不会泄漏到业务层。

共同契约测试不替代：

- 真实摄像机/NVR 厂商兼容性测试；
- 16 窗口实际硬件性能验收；
- ZLM 长时间稳定性和磁盘容量测试；
- SmartFire 前端权限、下载和业务数据范围测试；
- 整机部署、备份和恢复演练。

## 2. 测试事实源

优先级从高到低：

1. 版本化 OpenAPI 3.1 与 JSON Schema；
2. 本共同契约语义文档；
3. 版本化示例和契约测试用例；
4. Provider 实现代码。

实现代码与前三项冲突时，修复实现；不得通过修改测试去适配某个 Provider 的历史行为。语义文档与 OpenAPI 冲突时必须阻断基线发布并同时修正。

## 3. 建议的可执行制品布局

本轮只落地文档和计划。后续共同契约制品建议由 SmartFire 产品基线管理：

```text
contracts/video-provider/
├── openapi.yaml
├── schemas/
├── examples/
│   ├── devices/
│   ├── catalog/
│   ├── live/
│   ├── records/
│   └── events/
└── CHANGELOG.md
```

黑盒测试与两类模拟器放在同一个测试服务项目中，但保持独立内部模块：

```text
smartfire-video-testkit/
├── contract-tests/       # 对任意 Provider Base URL 执行
├── fake-provider/        # 给 SmartFire Consumer 使用
└── gb-device-simulator/  # 给 WVP/Gateway 使用
```

契约测试不得通过导入 Provider 代码调用内部方法；唯一被测 Interface 是 HTTP 和 Provider Event callback。

## 4. 工具基线建议

- OpenAPI：3.1；
- Schema：JSON Schema 2020-12；
- 黑盒 Runner：推荐 `pytest + httpx + jsonschema`，输出 JUnit XML 和 JSON 报告；
- OpenAPI 静态检查：使用可离线固定版本的 linter；
- 可选 Schema Fuzz：在基线稳定后引入，不作为第一版阻塞项；
- Provider 实现内部测试继续使用各自语言工具，不能替代黑盒共同测试。

选择独立黑盒 Runner 的原因：Java WVP Provider 与 Go sipgo Gateway 可以使用同一测试，不需要 Pact Broker，也不会因生成客户端而隐藏原始 HTTP 兼容问题。

## 5. 测试环境角色

```text
Contract Test Runner
    ├── HTTP -> Provider Under Test
    ├── control -> GB Device Simulator
    ├── HTTP -> ZLM（真实或受控 Stub）
    └── callback <- Provider Events
```

Provider Under Test（PUT）通过环境变量配置：

```text
PROVIDER_BASE_URL
PROVIDER_TOKEN
PROVIDER_INSTANCE_CODE
CONTRACT_VERSION
ZLM_BASE_URL
TEST_DEVICE_ID
TEST_CHANNEL_ID
```

不得把真实密码、token、地址或客户 GB ID 写进仓库。

## 6. 测试分层

### L0：静态契约

- OpenAPI 语法有效；
- 所有 `$ref` 可解析；
- Operation ID 唯一；
- 示例通过对应 Schema；
- Error Code、枚举和必填字段与语义文档一致；
- 检测破坏性变更。

### L1：HTTP 黑盒一致性

- 请求头、响应 Envelope、HTTP 状态；
- 分页、时间和 ID；
- Capabilities；
- 幂等和错误；
- 不依赖真实 SIP 设备的状态查询。

### L2：Provider + 模拟设备 + ZLM

- REGISTER/Digest、Keepalive、Catalog；
- 实时 INVITE/ACK/BYE；
- RTP/PS 到 ZLM；
- RecordInfo 和 Playback；
- 超时、离线和异常恢复；
- Provider Events。

### L3：SmartFire Consumer

- 一个 HTTP Adapter 同时消费 Mock/WVP/Gateway；
- Provider DTO 不进入 Web Controller；
- GB ID 映射、字段所有权、MISSING 恢复；
- 事件幂等和 reconciliation；
- Provider 错误映射为 SmartFire 产品错误；
- 平台录像和抓图继续经 ZLM Adapter，不依赖 Provider 数据库。

### L4：真实设备与整机

不属于共同契约自动门禁，但上线前必须另行执行。当前没有真实设备时，L0-L3 的通过结果只能声明“契约符合”，不能声明“厂商兼容”。

## 7. 固定测试夹具

测试数据必须稳定、可重复：

```text
Device A：单通道 IPC
Device B：多通道 NVR（至少 4 Channel）
Device C：离线设备
Channel A1：H.264 + Audio
Channel B1：H.264
Channel B2：H.265
Record Set：无录像、单条录像、多条分片响应
```

每次测试必须使用唯一 Provider Instance/Test Run ID，结束时释放流、清理回调和测试运行态。不得删除业务环境中的同 ID 资源。

## 8. 必选用例矩阵

### 8.1 通则与版本

| ID | 场景 | 期望 |
|---|---|---|
| `CT-GEN-001` | 正常请求 | `requestId` 回传或生成 |
| `CT-GEN-002` | 缺少/错误 Content-Type | 返回稳定 4xx 错误 |
| `CT-GEN-003` | 响应含新增未知字段 | Consumer 忽略并正常解析 |
| `CT-GEN-004` | Provider Contract 版本查询 | 与配置的主版本兼容 |
| `CT-GEN-005` | 错误响应 | 无堆栈、SQL、secret 和内部路径 |
| `CT-GEN-006` | 非法时间和 ID | `VIDEO_INVALID_ARGUMENT` |

### 8.2 健康与能力

| ID | 场景 | 期望 |
|---|---|---|
| `CT-HLT-001` | 进程存活 | `/health/live` 返回 `UP` |
| `CT-HLT-002` | 所有依赖就绪 | `/health/ready` 返回 `READY` |
| `CT-HLT-003` | ZLM 不可用 | `DEGRADED/NOT_READY` 与 HTTP 状态一致 |
| `CT-HLT-004` | 能力查询 | 必选能力全部声明 |
| `CT-HLT-005` | 调用未声明能力 | `VIDEO_CAPABILITY_NOT_SUPPORTED` |

### 8.3 设备与 Catalog

| ID | 场景 | 期望 |
|---|---|---|
| `CT-DEV-001` | 单通道设备注册 | Device/Channel 稳定 ID 正确 |
| `CT-DEV-002` | NVR 多通道 Catalog | 数量、父子和分页正确 |
| `CT-DEV-003` | 重复 Catalog | 不产生重复资源 |
| `CT-DEV-004` | 相同 Key 重复同步 | 返回同一 operation |
| `CT-DEV-005` | Catalog 超时 | `FAILED/PARTIAL` 与稳定错误正确 |
| `CT-DEV-006` | Channel 消失 | Provider 目录缺失，Consumer 标记 MISSING 不删除 |
| `CT-DEV-007` | Channel 再出现 | 恢复原绑定，不创建重复业务设备 |
| `CT-DEV-008` | 来源名称变化 | 不覆盖 SmartFire 业务名称和位置 |
| `CT-DEV-009` | 设备上下线 | 事件和查询最终一致 |
| `CT-DEV-010` | Catalog 在全量分页中变化或 snapshotToken 过期 | 整轮以 `VIDEO_CATALOG_SNAPSHOT_EXPIRED` 失败，不标 MISSING；重试后稳定快照收敛 |

### 8.4 实时流

| ID | 场景 | 期望 |
|---|---|---|
| `CT-LIVE-001` | H.264 通道启动 | 返回 `STREAMING` 和有效 Media Reference |
| `CT-LIVE-002` | 相同幂等 Key 重试 | 不创建第二条源流 |
| `CT-LIVE-003` | 同一通道并发启动 | 只建立一个等价源流或返回同一结果 |
| `CT-LIVE-004` | 离线设备启动 | `VIDEO_DEVICE_OFFLINE` |
| `CT-LIVE-005` | 不存在通道 | `VIDEO_CHANNEL_NOT_FOUND` |
| `CT-LIVE-006` | INVITE 超时 | 可判定的 timeout/error，不产生永久孤儿会话 |
| `CT-LIVE-007` | ZLM 不可用 | `VIDEO_MEDIA_UNAVAILABLE` |
| `CT-LIVE-008` | 重复 Stop | 幂等成功 |
| `CT-LIVE-009` | Stop 后检查 | SIP Dialog、SSRC/RTP 最终释放 |
| `CT-LIVE-010` | 请求超时后用相同 Key 重试 | 返回原结果或最终可判定状态 |

### 8.5 设备录像与回放

| ID | 场景 | 期望 |
|---|---|---|
| `CT-REC-001` | 无录像时间窗 | 成功且 items 为空 |
| `CT-REC-002` | 多条录像 | 时间、类型和稳定 recordKey 正确 |
| `CT-REC-003` | 多 MESSAGE/分页响应 | Provider 聚合，无重复项 |
| `CT-REC-004` | 查询部分超时 | `PARTIAL` 并保留已收集结果 |
| `CT-REC-005` | recordKey 启动回放 | 返回 PLAYBACK Stream |
| `CT-REC-006` | recordKey 与通道不匹配 | `VIDEO_RECORD_MISMATCH` |
| `CT-REC-007` | 重复启动/停止回放 | 幂等且无重复源流 |

### 8.6 事件与对账

| ID | 场景 | 期望 |
|---|---|---|
| `CT-EVT-001` | 在线事件 | Envelope/身份/时间正确 |
| `CT-EVT-002` | Callback 返回 500 | Provider 有界重试 |
| `CT-EVT-003` | 同一事件重复投递 | SmartFire 只应用一次 |
| `CT-EVT-004` | 事件乱序 | 旧 revision 不覆盖新状态 |
| `CT-EVT-005` | 丢弃事件 | reconciliation 最终修复 |
| `CT-EVT-006` | Provider 重启 | 目录和状态可重新建立 |
| `CT-EVT-007` | Callback 缺失/错误 Bearer token | 401/403，不持久化、不盲目重试认证错误 |
| `CT-EVT-008` | Provider 重启后旧 Epoch 事件迟到 | 不跨 `providerEpoch` 比较 revision，旧事件不覆盖新状态 |
| `CT-EVT-009` | 同一 Epoch/资源的 revision 乱序 | 仅无前导零 uint64 十进制 revision 可比较，较旧事件不覆盖 |

### 8.7 鉴权和脱敏

| ID | 场景 | 期望 |
|---|---|---|
| `CT-SEC-001` | 生产模式无 token | 401/403 |
| `CT-SEC-002` | 错误 token | 稳定认证错误 |
| `CT-SEC-003` | 日志和响应扫描 | 不含 token、密码、ZLM secret |
| `CT-SEC-004` | 构造内部路径/URL | Provider 不返回或使用非受控输入 |

## 9. 可选能力测试规则

- Capability 为 `true`：对应测试全部变为必选；
- Capability 为 `false`：调用返回 `VIDEO_CAPABILITY_NOT_SUPPORTED`；
- Capability 缺失：视为契约不符合，不能猜测；
- WVP 支持而 Gateway 暂不支持的能力不能变成 SmartFire 隐式依赖；
- 可选测试通过不抵消任何必选测试失败。

## 10. SmartFire Consumer 专项断言

共同测试除 HTTP 外，SmartFire 兼容层必须额外验证：

- 只使用 `externalDeviceId/externalChannelId` 建立绑定；
- Provider 数据库 ID 不进入 SmartFire；
- Provider `sourceName` 只更新来源字段；
- manufacturer/model 只在业务值为空时初始化；
- building/floor/location、业务名称和 enabled 状态不被同步覆盖；
- NVR Channel 可以分别绑定不同 `iot.device` 和空间位置；
- Provider 缺失只标记 MISSING，不级联删除录像和抓图；
- 事件按 `providerInstanceCode + eventId` 幂等；
- 全量对账可修复漏事件；
- 切换 WVP/Gateway 不改变 `iot.device.id` 和平台录像/抓图记录。

## 11. 测试报告与证据

每次运行至少输出：

```text
contractVersion
providerType/providerInstanceCode
implementationVersion/buildCommit
testRunId
开始/结束时间
通过/失败/跳过用例
Capabilities 快照
JUnit XML
机器可读 JSON Summary
脱敏后的 Provider/Simulator/ZLM 日志引用
```

失败证据必须包含 requestId、用例 ID、期望和实际结果；不得在报告中包含凭据和完整客户设备信息。

## 12. 发布门禁

Provider 可以声明“符合共同契约”必须同时满足：

1. L0 所有静态检查通过；
2. 所有必选 L1/L2 用例通过；
3. 已声明为 true 的可选能力用例通过；
4. 连续三次干净环境运行无偶发失败；
5. 流、RTP 端口、测试数据和回调无残留；
6. 没有未归类 5xx、线程泄漏或连接持续增长；
7. 报告包含实现版本和 Contract 版本；
8. SmartFire L3 Consumer 测试通过。

真实设备尚不可用时，报告结论必须写成：

```text
Provider Contract Conformant with Simulator
```

不得写成：

```text
GB28181 Vendor Compatible
```

## 13. 实施顺序

### Slice CT-1：机器可读契约

- 从共同规范生成/编写 OpenAPI 3.1；
- 建立 Schema、示例和 Changelog；
- 加入静态 lint、示例校验和 breaking-change 检查；
- 验收：L0 可在本地一条命令执行。

### Slice CT-2：黑盒 Runner 与 Fake Provider

- 实现通则、健康、能力、设备分页和错误测试；
- Fake Provider 完整实现必选 HTTP 契约；
- 验收：L1 对 Fake Provider 全绿，故意破坏字段时测试能够失败。

### Slice CT-3：GB28181 Device Simulator

- 实现 REGISTER/Digest、Keepalive、Catalog；
- 实现 INVITE/ACK/BYE 和固定 RTP/PS；
- 实现 RecordInfo 和 Playback；
- 提供正常、超时、离线、分片和乱序场景；
- 验收：场景可由 Runner API 确定性启动和复位。

### Slice CT-4：WVP Provider 门禁

- 对 `smartfire-wvp-provider` 执行全部 L1/L2；
- 补齐 PostgreSQL、Redis、ZLM 环境；
- 修复 WVP 差异，不修改契约去迎合历史接口；
- 验收：输出完整 Conformance Report。

### Slice CT-5：SmartFire Consumer 门禁

- 实现单一 HTTP Adapter；
- 使用 Fake Provider 验证同步、绑定、字段所有权、幂等和错误映射；
- 验收：同一测试配置切换 WVP Provider 时无需 Provider 类型分支。

### Slice CT-6：sipgo Gateway 门禁

- 复用 CT-1 至 CT-3 的全部制品；
- 不为 Gateway 新建第二套接口和测试；
- 验收：与 WVP Provider 使用相同命令和报告格式通过。

## 14. 完成定义

共同契约测试基线实施完成需要：

- 机器可读契约已纳入版本管理；
- Fake Provider 和 Device Simulator 可重复启动；
- WVP 与 sipgo 均使用同一 Runner；
- SmartFire Consumer 测试覆盖数据所有权和对账；
- 本地、CI 和交付验收使用同一用例 ID；
- Contract Changelog 能解释每次兼容或破坏性变化；
- 任一实现失败时，报告能够定位到共同契约条款和具体 requestId。

## 15. Skill 决策

当前**不创建**视频 Provider 项目 Skill。

原因：

- 契约尚未形成 OpenAPI 和可执行测试，Skill 会复制尚未验证的规则；
- 共同规范必须对人、Java、Go 和测试 Runner 同样有效，不能只存在于 AI 指令；
- 仓库已有规则明确要求团队规范优先固化在公共文档和 ADR。

满足以下条件后，可以在 `smartfire-repo/.agents/skills/smartfire-video-provider-change/` 增加薄 Skill：

1. OpenAPI 和黑盒 Runner 已稳定使用；
2. 至少一个真实 Provider 通过共同门禁；
3. 已经出现重复的 AI 修改流程，且现有 `smartfire-backend-change`/`smartfire-verification` 无法覆盖；
4. Skill 只引用本规范、OpenAPI 和验证命令，不复制字段、错误码和测试矩阵。
